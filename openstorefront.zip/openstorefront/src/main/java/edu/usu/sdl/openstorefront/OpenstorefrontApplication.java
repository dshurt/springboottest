package edu.usu.sdl.openstorefront;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OpenstorefrontApplication {

	public static void main(String[] args) {
		SpringApplication.run(OpenstorefrontApplication.class, args);
	}
}
